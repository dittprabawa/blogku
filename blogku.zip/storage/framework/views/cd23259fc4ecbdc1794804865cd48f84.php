<?php $__env->startSection('title', 'Categories'); ?>

<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\Category::class)): ?>
<div class="card" style="margin-bottom:20px">
    <h1>Kategori baru</h1>
    <form action="<?php echo e(route('admin.categories.store')); ?>" method="POST" style="display:flex; gap:10px; align-items:flex-start">
        <?php echo csrf_field(); ?>
        <div style="flex:1">
            <input type="text" name="name" placeholder="Nama kategori" value="<?php echo e(old('name')); ?>">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <button type="submit" class="btn">Tambah</button>
    </form>
</div>
<?php endif; ?>

<div class="card">
    <h1>Daftar kategori</h1>
    <table>
        <thead>
            <tr><th>Nama</th><th>Jumlah post</th><th></th></tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $category)): ?>
                            <form action="<?php echo e(route('admin.categories.update', $category)); ?>" method="POST" style="display:flex; gap:8px">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <input type="text" name="name" value="<?php echo e($category->name); ?>" style="max-width:220px">
                                <button type="submit" class="btn btn-sm btn-secondary">Simpan</button>
                            </form>
                        <?php else: ?>
                            <?php echo e($category->name); ?>

                        <?php endif; ?>
                    </td>
                    <td><?php echo e($category->posts_count); ?></td>
                    <td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $category)): ?>
                            <form action="<?php echo e(route('admin.categories.destroy', $category)); ?>" method="POST" onsubmit="return confirm('<?php echo e($category->posts_count > 0 ? 'PERINGATAN: Kategori ini memiliki ' . $category->posts_count . ' post yang terhubung. Kategori tidak dapat dihapus selama masih memiliki post.' : 'Yakin hapus kategori ini?'); ?>')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="3">Belum ada kategori.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/prabawa/jadi/resources/views/admin/categories/index.blade.php ENDPATH**/ ?>