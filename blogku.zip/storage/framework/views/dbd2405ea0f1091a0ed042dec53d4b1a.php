<?php $__env->startSection('title', 'Posts'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="top-bar">
        <h1>Posts</h1>
        <a href="<?php echo e(route('admin.posts.create')); ?>" class="btn">+ Post baru</a>
    </div>
    <table>
        <thead>
            <tr>
                <th></th>
                <th>Judul</th>
                <th>Kategori</th>
                <th>Status</th>
                <th>Penulis</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <?php if($post->featured_image): ?>
                            <img src="<?php echo e($post->featured_image_url); ?>" style="width:48px; height:48px; object-fit:cover; border-radius:4px">
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($post->title); ?></td>
                    <td><?php echo e($post->category->name); ?></td>
                    <td>
                        <span class="badge <?php echo e($post->status === 'published' ? 'badge-published' : 'badge-draft'); ?>">
                            <?php echo e($post->status); ?>

                        </span>
                    </td>
                    <td><?php echo e($post->user->name); ?></td>
                    <td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $post)): ?>
                            <a href="<?php echo e(route('admin.posts.edit', $post)); ?>" class="btn btn-sm btn-secondary">Edit</a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $post)): ?>
                            <form action="<?php echo e(route('admin.posts.destroy', $post)); ?>" method="POST" style="display:inline" onsubmit="return confirm('Yakin hapus post ini?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6">Belum ada post.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
    <div style="margin-top:16px"><?php echo e($posts->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/prabawa/blogku/resources/views/admin/posts/index.blade.php ENDPATH**/ ?>