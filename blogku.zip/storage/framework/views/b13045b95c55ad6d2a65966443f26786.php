<?php $__env->startSection('title', 'Edit post'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <h1>Edit post</h1>
    <form action="<?php echo e(route('admin.posts.update', $post)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <?php echo $__env->make('admin.posts._form', ['post' => $post], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <button type="submit" class="btn">Simpan perubahan</button>
        <a href="<?php echo e(route('admin.posts.index')); ?>" class="btn btn-secondary">Batal</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/prabawa/jadi/resources/views/admin/posts/edit.blade.php ENDPATH**/ ?>