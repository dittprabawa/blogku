<?php $__env->startSection('title', 'Post baru'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <h1>Post baru</h1>
    <form action="<?php echo e(route('admin.posts.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('admin.posts._form', ['post' => null], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <button type="submit" class="btn">Simpan</button>
        <a href="<?php echo e(route('admin.posts.index')); ?>" class="btn btn-secondary">Batal</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/prabawa/jadi/resources/views/admin/posts/create.blade.php ENDPATH**/ ?>